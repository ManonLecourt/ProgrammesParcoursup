const Calculer = document.querySelector('input[type=button]');

const random1 = document.getElementById("button1");
const random2 = document.getElementById("button2");

random1.addEventListener("click", hasard1);
random2.addEventListener("click", hasard2);

Calculer.addEventListener('click', calcIP);


function toString(data){
	var str = (data >> 24 & 0xFF).toString() + "." +
		(data >> 16 & 0xFF).toString() + "." + (data >> 8 & 0xFF).toString() + "." + (data & 0xFF).toString();
	return str;
}

function hasard1(min,max){
	var val1=(hasardbis(0,255)+"."+hasardbis(0,255)+"."+hasardbis(0,255)+"."+hasardbis(0,255));
    var form = document.querySelector('form');
    form.adrAl.value = val1;
	}

function hasard2(min,max){
	var val2=(hasardbis(0,255)+"."+hasardbis(0,255)+"."+hasardbis(0,255)+"."+hasardbis(0,255));
    var form = document.querySelector('form');
    form.masAl.value = val2;
	}
    
function hasardbis(min, max) {
        return min+Math.floor(Math.random()*(max-min+1));
}


function calcIP() {

	var form = document.querySelector('form');

  	var inputip = (form.ipinput.value);
	var inputmask = (form.sminput.value);
	var inputip2 = (form.ip2input.value);
    const inputcidr = (form.cidrinput.value);


	var ip = inputip.split('.');
	var ip2 = inputip2.split('.');
	var masque = inputmask.split('.');
  	//var cidr = inputcidr.split('/');
    
    var ret = checkInput(ip, masque, ip2);
  	if (ret != "OK") {
    alert("Attention, "+ret );
    return;
    }

  // tester ici si le masque n'a pas Ã©tÃ© saisi, 
  // auquel cas on examine si le CIDR est entrÃ©
  // dans ce cas, on convertit CIDR en format dÃƒÂ©veloppÃƒÂ© d'un masque 
  if (masque.length == 0) {
  	ret="OK";
  if (inputcidr.length != 0) {
  	 //VERIFICATION CIDR 
   if (inputcidr<0 || inputcidr>32){
   	alert("Attention, la valeur du CIDR n'est pas correcte");
   }
   
  // ici on convertit et on met Ã  jour le masque
  	var x = 32-parseInt(inputcidr);

    if(x>=1 && x<=24)
      {
        inputmask=toString(0xFFFFFFFF<<x);
      }
	/*var adrN2 = IP & CIDR ;
	form.subnetaddress.value = toString(adrN2);*/
      }
  }
     
	var IP = parseInt(ip[0]) << 24 | parseInt(ip[1]) << 16 | parseInt(ip[2]) << 8 | parseInt(ip[3]);
	var IP2 = parseInt(ip2[0]) << 24 | parseInt(ip2[1]) << 16 | parseInt(ip2[2]) << 8 | parseInt(ip2[3]);
	var mask = parseInt(masque[0]) << 24 | parseInt(masque[1]) << 16 | parseInt(masque[2]) << 8 | parseInt(masque[3]);
  

	var CIDR = 0;
	var m = mask;
	for (var i = 0; i < 32; i++) {
		if ((m & 0x01) == 0x00) CIDR++;
		else break;
		m= m >> 1;
	}
	
	//console.log(ip, mask.toString(16), masque,  CIDR);

	form.subsizebits.value = 32-CIDR;
	form.hostsizebits.value = CIDR;

	// network address (@reseau)
	var adrN = IP & mask ;
	form.subnetaddress.value = toString(adrN);

	// first address (1e @)
	var adrFirst = adrN + 1;
	form.starthost.value = toString(adrFirst);

	// boroadcast address (@diff)
	var adrDiff = adrN | ~mask;
	form.broadcastaddress.value = toString(adrDiff);

	// last address (derniÃƒÂ¨re@)
	var adrLast = adrDiff - 1;
	form.endhost.value  = toString(adrLast);

	// hosts number (nb @)
	var nb = Math.pow(2, CIDR) - 2;
	form.numofhosts.value = nb;


	//adresses compatibles
	var adrN2 = IP2 & mask;
	if (adrN2==adrN){
		form.compatibilite.value = "oui";
	} 
	else 
	{
		form.compatibilite.value = "non";
	}
}

// exercice : fonction Ãƒ  ÃƒÂ©crire et Ãƒ  valider 
function checkInput(ip,masque,ip2) {
	console.log(" --  "+ip+"  --  "+masque+"  --  "+ip2);
	// tester le nombre d'ÃƒÂ©lÃƒÂ©ments ip
  if(ip.length!=4) {return "la taille de l'IP n'est pas correcte";}
  // tester la valeur des ÃƒÂ©lÃƒÂ©ments ip
   if(ip[0]<0 || ip[0]>255) {return "l'adresse IP ne comporte pas des valeurs correctes";}
   if(ip[1]<0 || ip[1]>255) {return "l'adresse IP ne comporte pas des valeurs correctes";}
   if(ip[2]<0 || ip[2]>255) {return "l'adresse IP ne comporte pas des valeurs correctes";}
   if(ip[3]<0 || ip[3]>255) {return "l'adresse IP ne comporte pas des valeurs correctes";}

	// tester le nombre d'ÃƒÂ©lÃƒÂ©ments masque
   if(masque.length!=4) {return "la taille du masque n'est pas correcte";}
 // tester la valeur des ÃƒÂ©lÃƒÂ©ments ip2
   if(masque[0]<0 || masque[0]>255) {return "le masque ne comporte pas des valeurs correctes";}
   if(masque[1]<0 || masque[1]>255) {return "le masque ne comporte pas des valeurs correctes";}
   if(masque[2]<0 || masque[2]>255) {return "le masque ne comporte pas des valeurs correctes";}
   if(masque[3]<0 || masque[3]>255) {return "le masque ne comporte pas des valeurs correctes";}

	// tester le nombre d'ÃƒÂ©lÃƒÂ©ments ip2
  if(ip2>0 && ip2.length!=4) {return "la taille de l'IP 2 n'est pas correcte";}
   // tester la valeur des ÃƒÂ©lÃƒÂ©ments ip2
   if(ip2[0]<0 ||ip2[0]>255) {return "l'adresse IP 2 ne comporte pas des valeurs correctes";}
   if(ip2[1]<0 || ip2[1]>255) {return "l'adresse IP 2 ne comporte pas des valeurs correctes";}
   if(ip2[2]<0 || ip2[2]>255) {return "l'adresse IP 2 ne comporte pas des valeurs correctes";}
   if(ip2[3]<0 || ip2[3]>255) {return "l'adresse IP 2 ne comporte pas des valeurs correctes";}

	return "OK";  
}
calc_array = new Array();
var calcul=0;
var pas_ch=0;
function $id(id)
{
        return document.getElementById(id);
}
function f_calc(id,n)
{
        if(n=='ac')
        {
                initialiser_calc(id);
        }
        else if(n=='=')
        {
                if(calc_array[id][0]!='=' && calc_array[id][1]!=1)
                {
                        eval('calcul='+calc_array[id][2]+calc_array[id][0]+calc_array[id][3]+';');
                        calc_array[id][0] = '=';
                        $id(id+'_resultat').value=calcul;
                        calc_array[id][2]=calcul;
                        calc_array[id][3]=0;
                }
        }
        else if(n=='+-')
        {
                $id(id+'_resultat').value=$id(id+'_resultat').value*(-1);
                if(calc_array[id][0]=='=')
                {
                        calc_array[id][2] = $id(id+'_resultat').value;
                        calc_array[id][3] = 0;
                }
                else
                {
                        calc_array[id][3] = $id(id+'_resultat').value;
                }
                pas_ch = 1;
        }
        else if(n=='nbs')
        {
                if($id(id+'_resultat').value<10 && $id(id+'_resultat').value>-10)
                {
                        $id(id+'_resultat').value=0;
                }
                else
                {
                        $id(id+'_resultat').value=$id(id+'_resultat').value.slice(0,$id(id+'_resultat').value.length-1);
                }
                if(calc_array[id][0]=='=')
                {
                        calc_array[id][2] = $id(id+'_resultat').value;
                        calc_array[id][3] = 0;
                }
                else
                {
                        calc_array[id][3] = $id(id+'_resultat').value;
                }
        }
        else
        {
                        if(calc_array[id][0]!='=' && calc_array[id][1]!=1)
                        {
                                eval('calcul='+calc_array[id][2]+calc_array[id][0]+calc_array[id][3]+';');
                                $id(id+'_resultat').value=calcul;
                                calc_array[id][2]=calcul;
                                calc_array[id][3]=0;
                        }
                        calc_array[id][0] = n;
        }
        if(pas_ch==0)
        {
                calc_array[id][1] = 1;
        }
        else
        {
                pas_ch=0;
        }
        document.getElementById(id+'_resultat').focus();
        return true;
}
function add_calc(id,n)
{
        if(calc_array[id][1]==1)
        {
                $id(id+'_resultat').value=n;
        }
        else
        {
                $id(id+'_resultat').value+=n;
        }
        if(calc_array[id][0]=='=')
        {
                calc_array[id][2] = $id(id+'_resultat').value;
                calc_array[id][3] = 0;
        }
        else
        {
                calc_array[id][3] = $id(id+'_resultat').value;
        }
        calc_array[id][1] = 0;
        document.getElementById(id+'_resultat').focus();
        return true;
}
function initialiser_calc(id)
{
        $id(id+'_resultat').value=0;
        calc_array[id] = new Array('=',1,'0','0',0);
        document.getElementById(id+'_resultat').focus();
        return true;
}
function key_detect_calc(id,evt)
{
        if((evt.keyCode>95) && (evt.keyCode<106))
        {
                var nbr = evt.keyCode-96;
                add_calc(id,nbr);
        }
        else if((evt.keyCode>47) && (evt.keyCode<58))
        {
                var nbr = evt.keyCode-48;
                add_calc(id,nbr);
        }
        else if(evt.keyCode==107)
        {
                f_calc(id,'+');
        }
        else if(evt.keyCode==109)
        {
                f_calc(id,'-');
        }
        else if(evt.keyCode==106)
        {
                f_calc(id,'*');
        }
        else if(evt.keyCode==111)
        {
                f_calc(id,'');
        }
        else if(evt.keyCode==110)
        {
                add_calc(id,'.');
        }
        else if(evt.keyCode==190)
        {
                add_calc(id,'.');
        }
        else if(evt.keyCode==188)
        {
                add_calc(id,'.');
        }
        else if(evt.keyCode==13)
        {
                f_calc(id,'=');
        }
        else if(evt.keyCode==46)
        {
                f_calc(id,'ac');
        }
        else if(evt.keyCode==8)
        {
                f_calc(id,'nbs');
        }
        else if(evt.keyCode==27)
        {
                f_calc(id,'ac');
        }
        return true;
}
